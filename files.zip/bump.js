require("dotenv").config();
const { Client } = require("discord.js-selfbot-v13");

const client = new Client();

const CHANNEL_ID = process.env.CHANNEL_ID;
const TOKEN = process.env.TOKEN;
const DISBOARD_ID = "302050872383242240";

// 2 hours + random 1-5 min jitter so it looks human
const BUMP_INTERVAL = 2 * 60 * 60 * 1000;
const JITTER = () => Math.floor(Math.random() * 5 * 60 * 1000);

function log(msg) {
  const time = new Date().toLocaleString();
  const line = `[${time}] ${msg}`;
  console.log(line);

  const fs = require("fs");
  fs.appendFileSync("bump_log.txt", line + "\n");
}

async function bump() {
  try {
    const channel = await client.channels.fetch(CHANNEL_ID);
    if (!channel) {
      log("ERROR: Could not find channel. Check your CHANNEL_ID.");
      return;
    }

    await channel.sendSlash(DISBOARD_ID, "bump");
    log("✅ Bumped successfully!");
  } catch (err) {
    log(`❌ Bump failed: ${err.message}`);
  }
}

async function scheduleNext() {
  const wait = BUMP_INTERVAL + JITTER();
  const minutes = Math.floor(wait / 60000);
  log(`⏰ Next bump in ${minutes} minutes...`);

  setTimeout(async () => {
    await bump();
    scheduleNext();
  }, wait);
}

client.on("ready", async () => {
  log(`🟢 Logged in as ${client.user.tag}`);
  log(`📍 Bump channel: ${CHANNEL_ID}`);

  // bump immediately on start, then schedule
  await bump();
  scheduleNext();
});

client.on("error", (err) => {
  log(`❌ Client error: ${err.message}`);
});

process.on("uncaughtException", (err) => {
  log(`💥 Crash: ${err.message}`);
  log("🔄 Restarting in 30 seconds...");
  setTimeout(() => {
    process.exit(1); // bat will restart it
  }, 30000);
});

client.login(TOKEN);
